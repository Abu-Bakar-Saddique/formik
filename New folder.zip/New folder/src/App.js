import './App.css';
import LoginPage from './components/login/login';
import React from 'react';
function App() {
  return (
    <div className="App">
      <LoginPage/>
    </div>
  );
}

export default App;
